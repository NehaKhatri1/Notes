package check.streaming;

public class CustomObject {
	
	public CustomObject(String str){
		this.id = str;
	}
	
	public String id ;

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}
	
	
   
}
