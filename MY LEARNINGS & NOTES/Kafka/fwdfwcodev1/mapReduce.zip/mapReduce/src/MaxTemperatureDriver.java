

import java.io.IOException;

import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;
import org.apache.log4j.Logger;
/**
 * @description The class is used to run the map reduce code on the input data to generate the output data.
 * In totality , it is expected that the input file will be containing set of year and it's temperature 
 * recordings.
 * 
 * Also when running in training vm , it's needed to change domain from training
 * to localhost in both mapper and reducer.
 * 
 * Also one difference here is that , max temperature code here is having the setup and clean up 
 * methods , which are called once per mapper task which corresponds to each input split.
 * 
 * Ex : 
 * 
 * 1947 45
 * 1947 36
 * 1951 34
 * 1951 56
 * 1947 50
 * 1951 52
 * 
 * moving the input data file to hdfs from the edge node
 * 
 * [cloudera@quickstart jar]$ pwd
/home/cloudera/Documents/jar
[cloudera@quickstart jar]$ hdfs dfs -put file1.txt /user/cloudera/
( just possible to move it directly from Documents folder instead of the folders where all the hadoop jars are lying which are bounded to eclipse )

    commmand to run the hadop jar 
    hadoop jar run.jar MaxTemperatureDriver /user/cloudera/file1.txt output
 * 
 * The expected output is the highest temperature reading recorded per year : 
 * 
 * Ex : 
 * 
 * 1947 50
 * 1951 56
 * 
 * The trend of output shows that in reducer method , keys collated from mappers ( while each reducer is processing one partition ) , mean to say the keys from one partition which comes to reducer are sorted .
 * While this sorting , the keys are sorted in a way that numeric precedes alphabets .
 * 
 * The url to track the job : Following url gives you all details of execution provided you have implemented logger well in all your classes.
 * example ur in case of cloudera image : http://quickstart.cloudera:19888/jobhistory/task/task_1553233121326_0001_r_000000
 * 
 * one new set of input data and the data in the code used for setup cleanup along with output would explain setup cleanup
 * data:
1995 5
1995 8
1991 2
1991 3
1999 1
1999 10

Then after referring to these three values in setup cleanup method of reducer and mapper . Following is the result . 1950 is the frequent key used in setup cleanup 

output is : 
setupKeyReducer	1
1950	12
1991	3
1995	8
1999	10
setupKeyMapper	1
1950	12

explanation : 
setup  of reducer runs first and setupKeyReducer key value comes 
reduce method of reducer runs which brings all keys emitted by mappers in sorted way here . Starts with 1950 and ends with setupKeyMapper
cleanup method runs last on this reducer task to give the key with highest value which is 1950

 * 
 * @author Aparnesh.Gaurav
 *
 */
public class MaxTemperatureDriver {
	public static void main(String[] args) throws IOException, ClassNotFoundException, InterruptedException{
		Logger logger = Logger.getLogger(MaxTemperatureDriver.class);
		logger.info("**********************execution started*****************************");
		// setting the service class.
		Job job = new Job();
		job.setJarByClass(MaxTemperatureDriver.class);
		job.setJobName("Max temperature per year");
		
		// Giving the input and the output files here , both in hdfs.
		FileInputFormat.addInputPath(job, new Path(args[0]));
		FileOutputFormat.setOutputPath(job, new Path(args[1]));
		// setting the mapper and the reducer class.
		logger.info("*************specifying the mapper class in service ****************");
		job.setMapperClass( MaxTemperatureMapper.class);
		logger.info("*************specifying the reducer class in service ****************");
		job.setReducerClass( MaxTemperatureReducer.class);
		job.addCacheFile(new Path("/user/cloudera/file2.txt").toUri());
		// setting the data type of the output key and the value.
		job.setOutputKeyClass(Text.class);
		job.setOutputValueClass(IntWritable.class);
		// Getting the exception when the map reduce code is run.
		logger.info("**********************execution finished*****************************");
				
		System.exit(job.waitForCompletion(true) ? 0 :1);
	}
}


