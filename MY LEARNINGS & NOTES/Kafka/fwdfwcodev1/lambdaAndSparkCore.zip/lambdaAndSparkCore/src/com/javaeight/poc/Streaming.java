package com.javaeight.poc;

public class Streaming {

}
